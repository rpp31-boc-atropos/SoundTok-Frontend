"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkSoundTok_Frontend"] = self["webpackChunkSoundTok_Frontend"] || []).push([["src_pages_NotFound_jsx"],{

/***/ "./src/pages/NotFound.jsx":
/*!********************************!*\
  !*** ./src/pages/NotFound.jsx ***!
  \********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"./node_modules/react/index.js\");\n/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ \"./node_modules/react-router-dom/index.js\");\n\n // Any undefined path will be redirected to this page\n//Click the link to go back to the home page\n\nvar NotFound = function NotFound() {\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"h1\", null, \"404 Not Found\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_1__.Link, {\n    to: \"/\"\n  }, \"Go Back to the Home Page\"));\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (NotFound);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvTm90Rm91bmQuanN4LmpzIiwibWFwcGluZ3MiOiI7OztBQUFBO0NBSUE7QUFDQTs7QUFFQSxJQUFNRSxRQUFRLEdBQUcsU0FBWEEsUUFBVyxHQUFNO0FBQ3JCLHNCQUNFLGlIQUNFLDZFQURGLGVBRUUsaURBQUMsa0RBQUQ7QUFBTSxNQUFFLEVBQUM7QUFBVCxnQ0FGRixDQURGO0FBTUQsQ0FQRDs7QUFTQSwrREFBZUEsUUFBZiIsInNvdXJjZXMiOlsid2VicGFjazovL1NvdW5kVG9rLUZyb250ZW5kLy4vc3JjL3BhZ2VzL05vdEZvdW5kLmpzeD9hNDYzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5cblxuLy8gQW55IHVuZGVmaW5lZCBwYXRoIHdpbGwgYmUgcmVkaXJlY3RlZCB0byB0aGlzIHBhZ2Vcbi8vQ2xpY2sgdGhlIGxpbmsgdG8gZ28gYmFjayB0byB0aGUgaG9tZSBwYWdlXG5cbmNvbnN0IE5vdEZvdW5kID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8aDE+NDA0IE5vdCBGb3VuZDwvaDE+XG4gICAgICA8TGluayB0bz1cIi9cIj5HbyBCYWNrIHRvIHRoZSBIb21lIFBhZ2U8L0xpbms+XG4gICAgPC8+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBOb3RGb3VuZDtcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIkxpbmsiLCJOb3RGb3VuZCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/pages/NotFound.jsx\n");

/***/ })

}]);